//
//  main.cpp
//  Proj12
//
//  Created by 刘孟骁 on 2017/5/16.
//  Copyright © 2017年 刘孟骁. All rights reserved.
//

#include "account.hpp"
double SavingsAccount::total=0;

int main(int argc, const char * argv[]) {
    int operation;
    //初始化
    cout<<"欢迎光临银行，我们需要一些信息来建立您的个人档案。"<<endl;
    int number;
    double rate;
change_id:
    cout<<"请提供一个ID号：";
    cin>>number;
    cout<<"请提供您的年利率：";
    cin>>rate;
    SavingsAccount account(number,rate);
    account.set_current_date(1);
    
meau:
    cout<<endl<<"欢迎光临银行，请问有什么可以帮到您？"<<endl;
    cout<<"0.时光机"<<endl;
    cout<<"1.查询"<<endl;
    cout<<"2.存款"<<endl;
    cout<<"3.取款"<<endl;
    cout<<"4.结算"<<endl;
    cout<<"5.银行总金额"<<endl;
    cout<<"6.切换账号"<<endl;
    cout<<"我要：";
    cin>>operation;
    switch (operation) {
        case 0:
            account.set_current_date();
        case 1:
            account.show();
            break;
        case 2:
            account.deposit();
            break;
        case 3:
            account.withdraw();
            break;
        case 4:
            account.settle();
            cout<<endl<<"请问您是否离开银行？(Y/Any Key)"<<endl;
            char anwser;
            cin>>anwser;
            if (anwser=='Y'||anwser=='y')
                exit(0);
        case 5:
            account.getTotal();
            break;
        case 6:
            goto change_id;
            break;

        default:
            break;
    }
    goto meau;
    return 0;
}
