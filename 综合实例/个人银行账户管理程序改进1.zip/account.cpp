//
//  account.cpp
//  Proj12
//
//  Created by 刘孟骁 on 2017/5/16.
//  Copyright © 2017年 刘孟骁. All rights reserved.
//

#include "account.hpp"

void SavingsAccount::accumulate(){
    accumulation+=(current_date-lastDate)*balance;
    lastDate=current_date;
}
double SavingsAccount::record(double change){
    balance+=change;
    total+=change;
    cout<<"当前账户余额："<<balance<<endl;
    return balance;
}

SavingsAccount::SavingsAccount(int id,double rate){
    this->id=id;
    this->rate=rate;
    balance=0;
    lastDate=1;
    accumulation=0;
}
void SavingsAccount::set_current_date(int x){        //仅用于初始化
    current_date=x;
}
void SavingsAccount::set_current_date(){
    cout<<"请输入您要前往的存款天数：";
    cin>>current_date;
}
void SavingsAccount::show() const{
    cout<<"账号ID："<<id<<endl;
    cout<<"年利率："<<rate<<endl;
    cout<<"账户余额："<<balance<<endl;
}
void SavingsAccount::deposit(){
    double change;
    cout<<"请输入存款金额：";
    cin>>change;
    accumulate();
    record(change);
}
void SavingsAccount::withdraw(){
    double change;
    cout<<"请输入取款金额：";
    cin>>change;
    accumulate();
    record(-change);
}
void SavingsAccount::settle(){
    accumulation+=(current_date-lastDate)*balance;
    average_balance=accumulation/current_date;
    double change;
    change=average_balance*rate*(double(current_date)/365);
    record(change);
    accumulation=0;
}

//2017.5.16 加入三个新的部分
const double SavingsAccount::getBalance(){
    return balance;
}
const int SavingsAccount::getId(){
    return id;
}
const double SavingsAccount::getRate(){
    return rate;
}
double SavingsAccount::getTotal(){
    cout<<"当前的总金额为："<<total<<endl;
    return total;
}



