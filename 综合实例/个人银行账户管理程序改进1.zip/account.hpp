//
//  account.hpp
//  Proj12
//
//  Created by 刘孟骁 on 2017/5/16.
//  Copyright © 2017年 刘孟骁. All rights reserved.
//
#ifndef Header_h
#define Header_h



#include <iostream>
using namespace std;

class SavingsAccount{
private:
    int id;
    double balance;
    double rate;
    int lastDate;
    double accumulation;
    int current_date;
    double average_balance;
    static double total;
    void accumulate();
    double record(double change);
public:
    SavingsAccount(int id,double rate);
    void set_current_date(int x);
    void set_current_date();
    void show() const;
    void deposit();
    void withdraw();
    void settle();
    
    //2017.5.16 更新加入新的const变量
    const double getBalance();
    const int getId();
    const double getRate();
    //加入静态成员借口
    static double getTotal();
};

//2017.5.16 更新加入新的静态成员


#endif /* Header_h */
